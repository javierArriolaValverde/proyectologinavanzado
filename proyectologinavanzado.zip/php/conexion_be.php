<?php

$conexion = mysqli_connect("localhost", "myarriolab9", "mo7JGwAc", "proyectologinavanzado");

/*/
if ($conexion){
    echo "conectado";
}else{
        echo "no conectado";
}
*/

?>
